document.getElementById('apareix').addEventListener('click',(e)=>{
    const aside = document.getElementById('aside')
    const main = document.getElementById('main')
    const cssobj = window.getComputedStyle(aside,null)
    let display = cssobj.getPropertyValue("display")
    console.log(display)
    if (display=='block'){
        aside.style.display='none'
        main.style.width='100%'
    }
    else{
        aside.style.display='block'
        main.style.width='85%'
    }
    
}) 
document.getElementById('login').addEventListener('click',(e)=>
    {
        localStorage.setItem('logged', false);
        window.location.href = 'http://localhost:3001/index.html'
      
    })
    
    idUsuario=localStorage.getItem("id")
    console.log(idUsuario)
    fetch('/obtenerNombreUsuario', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ idUsuario: idUsuario }) // Envías la ID del usuario al servidor
    })
    .then(response => {
        if (response.ok) {
            return response.json();
        } else {
            throw new Error('Error en la respuesta del servidor');
        }
    })
    .then(data => {
        console.log('Nombre de usuario:', data.nombreUsuario)
        document.getElementById('nomense').innerHTML=data.nombreUsuario
    })
    .catch(error => {
        console.error('Error:', error);
    });