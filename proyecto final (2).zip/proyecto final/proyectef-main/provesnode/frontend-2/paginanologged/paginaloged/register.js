localStorage.setItem('logged', false);
document.getElementById('boton').addEventListener('submit',(e)=>{
e.preventDefault()
this.window.close()
         
    }
    
)

