const express = require('express');
const path = require('path');
const app = express();
const funciones = require('./Insert');
const login= require('./login')
const mysql = require('mysql2');
const fs = require('fs');
const bodyParser = require('body-parser');
const PORT = process.env.PORT || 3001;
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'frontend-2','paginanologged')));
// Ruta principal

app.get('/', (req, res) => {
    
    
    res.sendFile(path.join(__dirname, 'index.html'));
});
app.get('/formulario', (req, res) => {
    res.render('formulario');
});
// Iniciar el servidor


//Iniciar el servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en el puerto ${PORT}`);
});

//Base de datos
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'raul',
    password: 'raul',
    database: 'rauldb'
});
app.use(express.json());




// Conectar a la base de datos
connection.connect((err) => {
    if (err) {
        console.error('Error al conectar a MySQL:', err);
        return;
    }

    console.log('Conexión exitosa a MySQL');

    // Ejemplo: Consultar datos
    connection.query('SELECT * FROM usuarios', (err, rows) => {
        if (err) {
            console.error('Error al ejecutar consulta:', err);
            return;
        }

        console.log('Resultados de la consulta:', rows);
    });

    // Cerrar la conexión al terminar
   
});
app.use(express.urlencoded({ extended: true }));
app.get('/procesar', (req, res) => {
    // Obtener los valores del formulario desde los parámetros de consulta (query)
    const nombre = req.query.formulari1;
    
    const apellido = req.query.formulari2;

    const fichero = req.query.formulari0;
    

 

    console.log(fichero+'fichero')


    // Hacer algo con los valores obtenidos
  
    // console.log('Apellido:', apellido);
    try{
          funciones.insertarDatos(nombre,apellido,(err,result)=>{
            if  (err){
                res.status(500).send('Error interno del servidor');
                return;
            }
            else{
              
                
                };
                
            
        }
        
    )
    }
         catch (error) {
            console.error('Error al insertar datos:', error);
        }
        

    //     console.log('Datos insertados correctamente');
    //     res.send('Datos insertados correctamente');
    // });
   
    // resposta per a la consola
    console.log(nombre);
})
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.post('/login', (req, res) => {
const username = req.body.username;
const password = req.body.password;
console.log(password+username)


    

    const sql = 'SELECT id FROM usuarios WHERE username = ? AND password = ?';
  
  
    connection.query(sql, [username, password], function(error, results, fields){
      if (error) {
        console.error('Error al verificar las credenciales:', error);
        
        return;
      }
  
    
      
      if (results.length > 0) {
        lastring=results[0].id
        console.log(lastring)
        res.statusText=lastring
        res.status(200).json({
            lastring: lastring,
            message: '¡La operación fue exitosa!'
        });
      } else {
        
        res.sendStatus(205);
        
      
      }
    })
  });
  app.post('/obtenerNombreUsuario', (req, res) => {
    const idUsuario = req.body.idUsuario; // Obtiene la ID del usuario desde el cuerpo de la solicitud

    // Realiza la consulta a la base de datos para obtener el nombre del usuario
    connection.query('SELECT username FROM usuarios WHERE id = ?', [idUsuario], (error, results, fields) => {
        if (error) {
            console.error('Error al obtener el nombre del usuario:', error);
            res.status(500).send('Error en el servidor');
            return;
        }

        if (results.length > 0) {
            const nombreUsuario = results[0].username;
            console.log(results)
            res.status(200).json({ nombreUsuario: nombreUsuario }); // Devuelve el nombre del usuario al cliente
        } else {
            res.status(404).send('Usuario no encontrado');
        }
    });
});




    