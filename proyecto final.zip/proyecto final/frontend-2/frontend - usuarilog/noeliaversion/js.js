//añado un evento a window que es load para asegurarme que la funcion coso detecte los elementos ya cargados
window.addEventListener('load',creacionlistaypropiedades)
//
function creacionlistaypropiedades(){
    // CL1 creo la lista que sera donde aparecen sugerencias i le pongo una id que en el css ya tengo el estilo
    const elemente = document.createElement('ul')
    elemente.id='lallista'
    // CL2 busco el  div que contiene la barra de busqueda y el boton ,para añadir el elemento que antes habiamos creado, despues del div
    const eldiv=document.getElementById("buscar")
    eldiv.insertAdjacentElement('afterend',elemente)

    // CL3 busco el input
   const elinputbarra= document.getElementById('input')
    // CL4 añado un evento al propio documento para que al hacer click siempre que sea fuera del div se borre la lista (esto lo vi en chat gpt i esta to' guapo)
    document.addEventListener('click',
function(event){
    if(!eldiv.contains(event.target))
    {
        borrarllistachill()
    }
});
// CL5 añado propiedades a la barra y a el boton
    elinputbarra.addEventListener('input',atra)
    elinputbarra.addEventListener('reset',reset)
    elinputbarra.addEventListener('focus', atra)
    const boton = document.getElementById('boton')
    boton.addEventListener('click',limpiar)
}

//Esta funcion se usara para rellenar la lista que creamos antes en creacionlistaypropiedades()
function atra(){
    // A1 borrar lista ;3
    borrarllista()
     // A2 Selecciona el input saca su valor
    const inputvalue = document.getElementById("input").value
     // A3 Si el valor del input es diferente a  nada  creo una lista con todos los h2 del documento y una lista vacia 
    if (inputvalue!=""){            
     const llistaids=[]
     const llista=document.querySelectorAll('h2')
     // A4 Recorro una la lista de los h2 con un bucle forEach (se que te gustan los bucles) y por cada elemento le añado su respectivo id a la lista vacia que creamos antes
    llista.forEach(element => {
      
        llistaids.push(element.id)
    });
    //A5 Recorro la lista anteriormente creado como vacia y rellenada con los id de los h2 en el bucle anterior
    llistaids.forEach(element2 => {
        //A6 compruevo si cada valor de la lista de ids contiene el valor actual del input
        if(element2.includes(inputvalue)){
            //A7 creo un elemento lista  y le doy propiedades class para estilos y innertext con el valor de la lista actual 
            const add= document.createElement("li")
            add.className='los'
            add.innerHTML=element2
            add.tabIndex=i
            //A8 referencio a la lista anteriormente creada en creacion listaypropiedades() y le canvio algunas propiedades, posteriormente  añado la li recien creada 
            const llisyta=document.getElementById("lallista")
            llisyta.style.display="block"
            llisyta.appendChild(add);
            //A9 esta funcion luego te la exlico no seas impaciente
            dondarpropi()
            
        }
        
    }

    );
    }
    //A10 la otra parte del if es decir si el valor del input es nada
    else{
        
        const llistaids=[]
        const llista=document.querySelectorAll('h2')
         //A11 igual que lo anterior A4
        llista.forEach(element => {
         
           llistaids.push(element.id)
       });
        //A12 igual que lo anterior A5  pero aqui solo la recorro 3 veces (por la i) para que cuando no haya nada solo aparezcan 3
       i=0
       while (i<3){
            const add= document.createElement("li")
            const llisyta=document.getElementById("lallista")
            add.className='los'
            add.innerHTML=llistaids[i]
            llisyta.style.display="block"
            llisyta.appendChild(add);
             //A13 Ja casi solo un poco mas
            dondarpropi()
            i++
       }
    }
}
 //BC Funcion creada para hacer desaparecer la lista es la abreviacion de la funcion borrarllista()
function borrarllistachill(){
const llista = document.getElementById('lallista');
llista.style.display='none'
}
 //Bll Funcion hecha para destruir los objetos li que hemos introducido en la <ul> donde referencio al paadre para destruir su primer hijo hasta que no tenga
function borrarllista(){
    const llista = document.getElementById('lallista');
     //BLL2 llista.fistchild tambien es un booleano porque si no hay hijo devuelve false y si si pos true
    while (llista.firstChild) {
        llista.removeChild(llista.firstChild);
    }
}
 //DP1 en esta funcion daremos propiedades de eventos a los li creados
function dondarpropi(){
     //DP2 consigo la lista de todos los 'los' que son solamente los <li> que yo he creado
    const llistes = document.getElementsByClassName('los')
     //DP3 recorro la lista y a cada elemnto li le asigno propiedades
    for (var i = 0; i < llistes.length; i++) {
        // Acceder a cada elemento de la colección por su índice
        var elemento = llistes[i];
        elemento.addEventListener('mouseover',canviar)
        elemento.addEventListener('click',valor)
       
        // Hacer algo con cada elemento, por ejemplo, imprimir su contenido
      
}


}
 //Realmente no se para que sirve esta funcion pero la use para ejecutar 
function valor(){
    console.log('entra')
     document.getElementById("input").value=this.textContent
    atra()
}
 //AN La funcion del boton la que nos hara desplazarnos al h2 que mencionamos
function anar(){

   
     //AN2 Sacar el valor del input para buscar un elemento con id igual a el valor del input 
   var anara = document.getElementById("input")
   var aa= document.getElementById(anara.value)
    //AN3 Borrar valor del input 
   anara.value=""
    //AN4 Aqui hago un try catch porque puede ser que el elemento no exista y pues no quiero que pete todo simplemente lo identifico y ya
   try{
    //si a un elemento le añades la funcion scroll to view  pues sorpresa la pantalla se escrolea o desliza(soy bilingue) hasta el elemento y cambia el color del h2 correspondiente  
    aa.scrollIntoView(true)
    aa.style.color="red"
   }
   catch(e){
    console.log("La array llita es nula s"+ e )
   }
   
    //A que no sabes que hace este metodo
   
    borrarllista()
}
//Esto no funciona ahora pero es para que  todos vuelvan a ser azules i solo haya un rojo
function limpiar(){
    
    const llista=document.querySelectorAll('h2')
    llista.forEach(element => {
      
        element.style.color='cian'
        element.style.fontSize='32px'
    });
    anar()
}
//funcion para el hover de la lista creada para que se ponga de placeholder 
function canviar(){
    const x= document.getElementById('input')
    x.placeholder=this.innerHTML
}
//A estas alturas ya no importa que hace esto verdad?                                                                                                                                    No lo se
function reset(){
    this.placeholder="Bucar dentro de la web"
}
//Muchas gracias por interesarte en mi programacion pero como se que es un poco erratica a veces te he preparado esto que no me cuesta nada
//y se que aunque solo aprendieras una cosa ya te habria servido de algo , pido perdon por alguna faltas ortografícas que seguro hay por todos los comentarios
// Si tienes alguna duda (que seguramente la tendras) puedes contactar mediante medios habituales e intentare que entiendas mejor algo nada mas sigue con tus bucles disfruta del
//sabado que para eso esta y nos vemos el lunes (espero)


























































































//TE ESPEABAS UN MENSAJE SECRETO?






















































































































































































//<3

