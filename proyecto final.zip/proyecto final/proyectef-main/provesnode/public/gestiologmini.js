localStorage.setItem('logged', false);
document.getElementById('login').addEventListener('submit',(e)=>{
e.preventDefault()

const datosUsuario = {
    username: document.getElementById('username').value,
    password: document.getElementById('password').value
};

fetch('/login', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify(datosUsuario)
})
.then(response => {
    if (response.status === 205) {
        console.log('\x1b[31m%s\x1b[0m', 'Acceso denegado');
        document.getElementById('username').style.border=' 1px solid red'
        document.getElementById('password').style.border='1px solid red'

        // Realiza las acciones snecesarias cuando el acceso es denegado
    } else if (response.status === 204) {
        localStorage.setItem('logged', true);
        console.log('\x1b[32m%s\x1b[0m', 'Aceso Permitido' );
        sino = localStorage.getItem('logged')
        this.window.close()
        


        // Maneja otros códigos de estado de error según sea necesario
    }
    
})
.catch(error => {
    console.error('Error al realizar la solicitud:', error);
})
}
);