document.getElementById('logear').addEventListener('click',(e)=>{
    const left = (window.innerWidth - 400) / 2;
    const top = (window.innerHeight - 300) / 2;
    const ventana = window.open('menu.html', 'Menu', `width=${400}, height=${300}, left=${left}, top=${top} toolbar=no,location=no, 
    directories=no, 
    status=no, 
    location=no,
    menubar=no, 
    menubar=no,
    scrollbars=no, 
    resizable=no  `);
    if (ventana) {
        ventana.focus(); // Da foco a la ventana emergente
      
      } else {
        alert('El navegador bloqueó la ventana emergente. Por favor, habilita las ventanas emergentes para este sitio web.');
      }
    
})
document.getElementById('Register').addEventListener('click',(e)=>{
    const left = (window.innerWidth - 400) / 2;
    const top = (window.innerHeight - 300) / 2;
    const ventana = window.open('register.html', 'Register', `width=${400}, height=${300}, left=${left}, top=${top} toolbar=no,location=no, 
    directories=no, 
    status=no, 
    location=no,
    menubar=no, 
    menubar=no,
    scrollbars=no, 
    resizable=no  `);
    if (ventana) {
        ventana.focus(); // Da foco a la ventana emergente
      
      } else {
        alert('El navegador bloqueó la ventana emergente. Por favor, habilita las ventanas emergentes para este sitio web.');
      }
    
})