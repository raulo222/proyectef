document.getElementById('apareix').addEventListener('click',(e)=>{
    const aside = document.getElementById('aside')
    const main = document.getElementById('main')
    const cssobj = window.getComputedStyle(aside,null)
    let display = cssobj.getPropertyValue("display")
    console.log(display)
    if (display=='block'){
        aside.style.display='none'
        main.style.width='100%'
    }
    else{
        aside.style.display='block'
        main.style.width='85%'
    }
    
}) 
//fer els spans fondo balu cuan clickes
const elementosHTML = document.querySelectorAll('.spans');
elementosHTML.forEach(elemento => {
    // Realiza operaciones en cada elemento HTML aquí
    
    elemento.addEventListener('click',(e)=>
    {
        const cssobj = window.getComputedStyle(elemento,null)
        color= cssobj.getPropertyValue('background-color')
        console.log(color)
        if(color=="rgb(0, 0, 0)"){
            elemento.style.backgroundColor="#abc4ff"
        }
        else{
            elemento.style.backgroundColor="black"
        }
        
    })
   
});