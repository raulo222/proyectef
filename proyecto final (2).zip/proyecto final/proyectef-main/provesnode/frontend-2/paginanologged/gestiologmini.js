localStorage.setItem('logged', false);
document.getElementById('login').addEventListener('submit',(e)=>{
e.preventDefault()

const datosUsuario = {
    username: document.getElementById('username').value,
    password: document.getElementById('password').value
};

fetch('/login', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify(datosUsuario)
})
.then(response => {
    if (response.status === 205) {
        console.log('\x1b[31m%s\x1b[0m', 'Acceso denegado');
        document.getElementById('username').style.border = '2px solid red';
        document.getElementById('password').style.border = '2px solid red';
        localStorage.setItem('logged', false);
        console.log('\x1b[32m%s\x1b[0m', 'Aceso Permitido' );
        sino = localStorage.getItem('logged')
       
        // Realiza las acciones necesarias cuando el acceso es denegado
    } else if (response.ok) {
        

        document.getElementById('username').style.border = '3px solid green';
        document.getElementById('password').style.border = '3px solid green';
        return response.json(); // Convertir la respuesta a JSON si es exitosa
    } else {
        throw new Error('Error en la respuesta del servidor');
    }
})
.then(data => {
    if (data && data.lastring) {
        console.log('Mensaje del servidor:', data.lastring);
        localStorage.setItem('id', data.lastring);
        localStorage.setItem('logged', true);
        sino=localStorage.getItem('logged')
        var urlActual = window.location.href;
    var rutaDirectorioActual = urlActual.substring(0, urlActual.lastIndexOf("/") + 1);
    var nuevaRuta = rutaDirectorioActual + "paginaloged/";
    var nuevaURL = nuevaRuta + "index.html";
    setTimeout(() => {
        this.window.close()
        window.location.href = nuevaURL;
        if (window.opener && !window.opener.closed && sino==('true')) {
            console.log("Se va ha tancar i va a canviar")
            window.opener.location.href = nuevaRuta;
        }
      }, "2000");
    
        
       
           
          
        
        // Asegúrate de acceder a 'message' correctamente
    } else {
        throw new Error('La respuesta del servidor no contiene la variable "lastring"');
    }
})
.catch(error => {
    console.error('Error:', error);
});
  
}
);

 var sino = localStorage.getItem('logged')
window.onbeforeunload = function() {
    
    var urlActual = window.location.href;

    // Obtener la ruta del directorio actual eliminando el nombre del archivo
    var rutaDirectorioActual = urlActual.substring(0, urlActual.lastIndexOf("/") + 1);
    
    // Construir la URL del directorio "html2" dentro del directorio actual
    var nuevaRuta = rutaDirectorioActual + "paginaloged/";
    
    // Construir la URL completa del archivo "index.html" dentro del directorio "html2"
    var nuevaURL = nuevaRuta + "index.html";
    window.location.href = nuevaURL;
    if (window.opener && !window.opener.closed && sino==('true')) {
        console.log("Se va ha tancar i va a canviar")
        window.opener.location.href = nuevaRuta;
    }
};