document.getElementById('apareix').addEventListener('click',(e)=>{
    const aside = document.getElementById('aside')
    const main = document.getElementById('main')
    const cssobj = window.getComputedStyle(aside,null)
    let display = cssobj.getPropertyValue("display")
    console.log(display)
    if (display=='block'){
        aside.style.display='none'
        main.style.width='100%'
    }
    else{
        aside.style.display='block'
        main.style.width='85%'
    }
    
}) 
// document.getElementById("ge").addEventListener('click',
//     (e)=>{
        
//     }
// )
